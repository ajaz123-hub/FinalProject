package com.book.books.constants;

public class HttpCalls {

	public static final String BLOCKBOOK = "http://localhost:8092/reader/blockbookforuser?bookId=";

}
